let data = [
    { title: "校长", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "院长", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "主任", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "讲师", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "辅导员", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "就业指导老师", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "督查", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "教务", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "班长", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "学委", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "纪委", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "安委", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "生委", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
    { title: "文化书记", price: Math.ceil(Math.random() * 500), count: 1, flag: false },
]

export default data