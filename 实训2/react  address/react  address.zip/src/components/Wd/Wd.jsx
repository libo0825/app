import React, { Component } from "react"
import "./Wd.css"

class Wd extends Component {
    render() {
        return (
            <div id="Wd">
                <div className="head">
                    <span>我的</span>
                </div>
                我的
            </div>
        )
    }
}

export default Wd